let cart = [];

// Add product to cart with quantity management
function addToCart(product, price) {
    let existingProduct = cart.find(item => item.product === product);

    if (existingProduct) {
        existingProduct.quantity++;
    } else {
        cart.push({ product, price, quantity: 1 });
    }

    displayCartNotification();
}

// Display cart notification
function displayCartNotification() {
    let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    alert(`You have ${totalItems} item(s) in your cart.`);
}

// Checkout and store cart data
function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty.');
        return;
    }

    let total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    localStorage.setItem('cart', JSON.stringify(cart)); // Store cart in localStorage
    localStorage.setItem('total', total);

    window.location.href = 'invoice.html'; // Redirect to invoice page
}
