// Set a tax rate (e.g., 15%)
const TAX_RATE = 0.15;

// Function to display cart items and total price on the invoice page
function displayInvoice() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartItemsContainer = document.getElementById('cart-items');
    let subtotal = 0;

    // Object to store the quantity of each item
    const groupedCart = {};

    // Group identical items and count their quantity
    cart.forEach(item => {
        if (groupedCart[item.name]) {
            groupedCart[item.name].quantity += 1;
        } else {
            groupedCart[item.name] = { ...item, quantity: 1 };
        }
    });

    // Clear previous content (if any)
    cartItemsContainer.innerHTML = '';

    // Loop through the grouped cart items and display them
    Object.values(groupedCart).forEach((item, index) => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('cart-item');
        const totalItemPrice = item.price * item.quantity;
        itemElement.innerHTML = `
            <button class="delete-item" onclick="deleteItem(${index})">🗑️</button>
            <span class="item-name">${item.name} (x${item.quantity})</span>
            <span class="item-price">+ $${totalItemPrice.toFixed(2)}</span>
        `;
        cartItemsContainer.appendChild(itemElement);
        subtotal += totalItemPrice;
    });

    // Calculate tax and total
    const tax = subtotal * TAX_RATE;
    const total = subtotal + tax;

    // Display the subtotal, tax, and total
    document.getElementById('subtotal-price').innerHTML = `Subtotal: $${subtotal.toFixed(2)}`;
    document.getElementById('tax-amount').innerHTML = `Tax (15%): $${tax.toFixed(2)}`;
    document.getElementById('total-price').innerHTML = `<strong>Total: $${total.toFixed(2)}</strong>`;
}

// Function to delete an item from the cart
function deleteItem(index) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Remove the item at the specified index
    cart.splice(index, 1);

    // Update localStorage with the new cart data
    localStorage.setItem('cart', JSON.stringify(cart));

    // Re-display the updated cart and total price
    displayInvoice();
}

// Function to confirm the purchase (simulated)
function confirmCheckout() {
    alert('Thank you for your purchase!');

    // Clear the cart after the purchase is confirmed
    localStorage.removeItem('cart');
    
    // Optionally redirect the user back to the products page
    window.location.href = 'products.html';
}

// Call the function to display the invoice on page load
window.onload = function() {
    displayInvoice();
}
