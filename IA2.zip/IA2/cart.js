// Initialize cart from localStorage or set to empty array
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Function to add an item to the cart
function addToCart(productName, productPrice) {
    const product = { name: productName, price: productPrice };

    // Add product to the cart array
    cart.push(product);

    // Store the updated cart in localStorage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Update cart count display
    updateCartCount();

    // Show the success message
    showMessage(`${productName} added to cart!`);
}

// Function to update the number of items in the cart
function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    
    // Update the cart count element with the length of the cart array
    cartCount.textContent = cart.length;
}

// Function to display a message when an item is added to the cart
function showMessage(message) {
    const messageContainer = document.getElementById('message-container');
    messageContainer.textContent = message;
    messageContainer.style.display = 'block'; // Show the message

    // Hide the message after 3 seconds
    setTimeout(() => {
        messageContainer.style.display = 'none';
    }, 3000);
}

// Initialize the cart count when the page loads
window.onload = function() {
    updateCartCount();
}
